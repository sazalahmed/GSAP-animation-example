# Snap Scroll Effect using GSAP

![Thumbnail](thumbnail.png)

Full tutorial here: https://youtu.be/hi9U2Slk1M4

