# Cool Full Page Navigation Hover Effect using HTML & CSS only

![Thumbnail](thumbnail.png)

Full tutorial here: https://youtu.be/jj6VmBcqJHg?feature=shared

