# Stunning Scroll Animation with GSAP

![Thumbnail](thumbnail.png)

Full tutorial here: https://www.youtube.com/watch?v=kdVu4eFgKkY

Images (not in repo): https://wirestock.io/james591
