# Beautiful Text Reveal Animation using HTML & CSS

![Thumbnail](thumbnail.png)

Full tutorial here: https://youtu.be/qCYfdhZqGxs

Images (not in repo): https://wirestock.io/james591
